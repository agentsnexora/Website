When updating the project
- Always check if the `trickle/notes/README.md` needs to be updated to reflect changes in project structure, features, or setup instructions.
- Keep the README concise but informative for future developers.