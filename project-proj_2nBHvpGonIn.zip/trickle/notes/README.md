# NEXORA - Next-Gen Digital Agency Website

## Overview
This is a futuristic, 3D-styled website for NEXORA, a digital branding and development agency.

## Key Features
- **Ultra-modern Dark Theme**: Black, Electric Blue, and Neon Purple palette.
- **3D CSS Effects**: Floating cards, tilt interactions, and gradient glows.
- **Sections**: Hero, About, Services, Portfolio, Why Nexora, Testimonials, Contact.
- **Animations**: Powered by AOS (Animate On Scroll) and Anime.js for complex motion.
- **Services Focus**: Website Development, AI Agents, Meta Ads.

## Tech Stack
- React 18
- TailwindCSS
- Lucide Icons
- AOS (Animate On Scroll)
- Anime.js

## Updates
- Initial setup: Feb 2026
- Major Update Mar 2026: Removed auth system, added AOS/Anime.js, updated service offerings.